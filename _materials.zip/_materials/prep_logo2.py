from PIL import Image

OUT = r"D:/workbuddy/2026-10-19-09-47-25/assets/img"
src = Image.open(f"{OUT}/logo-green.png")
w, h = src.size

mark = src.crop((0, 0, 68, h))
mark.save(f"{OUT}/logo-mark.png")
mark_white = Image.open(f"{OUT}/logo-green-white.png").crop((0, 0, 68, h))
mark_white.save(f"{OUT}/logo-mark-white.png")


def square(img, size, pad_ratio=0.14):
    inner = int(size * (1 - pad_ratio * 2))
    k = inner / max(img.size)
    r = img.resize((max(1, int(img.size[0] * k)), max(1, int(img.size[1] * k))), Image.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.paste(r, ((size - r.size[0]) // 2, (size - r.size[1]) // 2), r)
    return canvas


square(mark, 180).save(f"{OUT}/favicon-180.png")
square(mark, 64).save(f"{OUT}/favicon-64.png")
mark.save(f"{OUT}/apple-touch-icon.png")
print("mark", mark.size, "logo", (w, h))
