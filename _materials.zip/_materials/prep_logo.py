from PIL import Image
import numpy as np

SRC = r"C:\Users\yanxi\Desktop\logo.png"
OUT = r"D:/workbuddy/2026-10-19-09-47-25/assets/img"

im = Image.open(SRC).convert("RGB")
a = np.array(im).astype(float)


def extract(box, name):
    """box=(l,t,r,b) 在整图上截取；白底转透明并反预乘，保留抗锯齿边缘"""
    l, t, r, b = box
    crop = a[t:b, l:r]
    mn = crop.min(axis=2)
    alpha = np.clip((255.0 - mn) / 255.0, 0, 1)
    safe = np.where(alpha > 0.02, alpha, 1.0)[..., None]
    color = np.clip((crop - 255.0 * (1.0 - safe)) / safe, 0, 255)
    out = np.dstack([color, alpha * 255]).astype(np.uint8)
    img = Image.fromarray(out, "RGBA")
    # 按内容再裁一次，去掉多余白边
    bb = img.getbbox()
    img = img.crop(bb)
    img.save(f"{OUT}/{name}")
    print(name, img.size)

    # 白/深色版本：保持 alpha，替换颜色
    arr = np.array(img)
    al = arr[:, :, 3:4]
    for suffix, rgb in (("white", (255, 255, 255)), ("ink", (19, 36, 26))):
        v = np.concatenate([np.zeros_like(al) + np.array(rgb, dtype=np.uint8), al], axis=2)
        Image.fromarray(v, "RGBA").save(f"{OUT}/{name.replace('.png', '-' + suffix + '.png')}")


extract((30, 50, 520, 126), "logo-green.png")
extract((30, 187, 520, 263), "logo-dark.png")

# 图标部分（左侧轮式图形）单独导出，做 favicon
src = Image.open(f"{OUT}/logo-green.png")
w, h = src.size
mark = src.crop((0, 0, int(h * 1.06), h))
mark.save(f"{OUT}/logo-mark.png")
for s in (64, 180):
    mark.resize((s, int(s * mark.size[1] / mark.size[0])), Image.LANCZOS).save(f"{OUT}/favicon-{s}.png")
print("mark", mark.size)
