import pdfplumber

path = r"C:\Users\yanxi\Desktop\宁波轮上机器人科技有限公司 2026-10.pdf"
out = r"D:\workbuddy\2026-10-19-09-47-25\pdf_text.txt"

parts = []
with pdfplumber.open(path) as pdf:
    for i, page in enumerate(pdf.pages):
        t = page.extract_text() or ""
        parts.append(f"\n===== Page {i+1} =====\n" + t)

text = "\n".join(parts)
with open(out, "w", encoding="utf-8") as f:
    f.write(text)

print("PAGES:", len(parts), "CHARS:", len(text))
print(text[:4000])
