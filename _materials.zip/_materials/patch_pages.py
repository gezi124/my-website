import io
import os
import re

ROOT = r"D:/workbuddy/2026-10-19-09-47-25"
files = ["index.html", "products.html", "about.html", "news.html", "contact.html"]

FAV_OLD = '<link rel="icon" href="assets/img/logo.png">'
FAV_NEW = (
    '<link rel="icon" type="image/png" sizes="64x64" href="assets/img/favicon-64.png">\n'
    '<link rel="icon" type="image/png" sizes="180x180" href="assets/img/favicon-180.png">\n'
    '<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">'
)

for f in files:
    p = os.path.join(ROOT, f)
    s = io.open(p, encoding="utf-8").read()
    orig = s
    s = s.replace(FAV_OLD, FAV_NEW)
    s = s.replace("轮上科技 WHEELBOTS ", "轮上科技 WHEELBOTS.AI ")
    s = s.replace("轮上科技 WHEELBOTS —", "轮上科技 WHEELBOTS.AI —")
    s = s.replace("轮上科技 WHEELBOTS 公司动态", "轮上科技 WHEELBOTS.AI 公司动态")
    if s != orig:
        io.open(p, "w", encoding="utf-8").write(s)
        print("updated", f)
    else:
        print("nochange", f)
