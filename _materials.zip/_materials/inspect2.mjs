import { spawn } from "child_process";
import http from "http";
import fs from "fs";

const EDGE = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const URL_ = process.argv[2];
const W = parseInt(process.argv[3] || "390", 10);
const H = parseInt(process.argv[4] || "844", 10);
const OUT = process.argv[5] || "";

const proc = spawn(EDGE, [
  "--headless=new",
  "--disable-gpu",
  "--remote-debugging-port=9333",
  "--user-data-dir=D:\\workbuddy\\2026-10-19-09-47-25\\_materials\\edge-profile",
  "--window-size=800,900",
  "about:blank",
]);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function getJson(path) {
  return new Promise((resolve, reject) => {
    http.get({ host: "127.0.0.1", port: 9333, path }, (res) => {
      let d = "";
      res.on("data", (c) => (d += c));
      res.on("end", () => resolve(JSON.parse(d)));
    }).on("error", reject);
  });
}

let targets = null;
for (let i = 0; i < 40; i++) {
  try { targets = await getJson("/json/list"); break; } catch (e) { await sleep(300); }
}
const page = targets.find((t) => t.type === "page");
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 0;
const pending = new Map();
const send = (method, params = {}) =>
  new Promise((resolve) => {
    const mid = ++id;
    pending.set(mid, resolve);
    ws.send(JSON.stringify({ id: mid, method, params }));
  });
await new Promise((r) => (ws.onopen = r));
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); }
};

await send("Page.enable");
await send("Runtime.enable");
await send("Emulation.setDeviceMetricsOverride", {
  width: W, height: H, deviceScaleFactor: 2, mobile: true,
});
await send("Page.navigate", { url: URL_ });
await sleep(1800);

const r = await send("Runtime.evaluate", {
  expression: `(() => {
    const de = document.documentElement;
    const out = { innerW: innerWidth, docW: de.scrollWidth };
    const bad = [];
    document.querySelectorAll("*").forEach(el => {
      const b = el.getBoundingClientRect();
      if (b.right > innerWidth + 1 && b.width > 0) bad.push(el.tagName + "." + (typeof el.className === "string" ? el.className : "") + " right=" + Math.round(b.right));
    });
    out.overflow = bad.slice(0, 10);
    return JSON.stringify(out);
  })()`,
  returnByValue: true,
});
console.log(r.result.value);

if (OUT) {
  const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true });
  fs.writeFileSync(OUT, Buffer.from(shot.data, "base64"));
  console.log("saved", OUT);
}
ws.close();
proc.kill();
process.exit(0);
