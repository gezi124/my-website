# -*- coding: utf-8 -*-
"""Unify English company name and polish/concise all English copy.
Each replacement is verified to hit exactly the expected number of times.
"""
import io, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (file, old, new, expected_count)
P = []


def add(f, old, new, n=1):
    P.append((f, old, new, n))


# ---------------- app.js: company name ----------------
add("assets/js/app.js", "Ningbo Wheelbots Robotics Co., Ltd.", "Wheelbots Co. Ltd.", 2)

# ---------------- index.html ----------------
add("index.html",
    "We bring EV and intelligent-driving technology from the automotive industry into field autonomy and machine vision — one modular platform, many field operations.",
    "We bring automotive electrification, autonomy and machine vision to farming — one modular platform, many operations.")
add("index.html",
    "Platform-based design with standardized interfaces, adapting to various field conditions and implements.",
    "Standardized interfaces adapt the platform to diverse fields and implements.")
add("index.html", "增程 / Range-ext.", "增程 / Range-extender")
add("index.html",
    "Full-stack in-house, platform-based field operations",
    "Full-stack, in-house technology for platform-based farming.")
add("index.html",
    "Standardized interfaces for weeding, spraying, topping, thinning, monitoring, harvesting and transport modules.",
    "Standardized interfaces support weeding, spraying, topping, thinning, monitoring, harvesting and transport modules.")
add("index.html",
    "Independent torque steering per wheel; high-integration corner modules; up to 1200 N·m × 4 at the wheel.",
    "Independent torque steering per wheel, integrated corner modules, and up to 1200 N·m × 4 at the wheel.")
add("index.html",
    "IPU intelligent control unit plus ZCU zone controllers on an open electronic architecture.",
    "An IPU control unit and ZCU zone controllers on an open, high-compute architecture.")
add("index.html",
    "Vision-based on-site autonomy that greatly improves efficiency and reduces labor demand.",
    "Vision-based autonomy boosts efficiency and cuts labor demand.")
add("index.html",
    "Co-developed with industry leaders. Unmanned driving and operation, covering over 90% of field scenarios.",
    "Co-developed with industry leaders for unmanned driving and operation, covering over 90% of field scenarios.")
add("index.html", "All-weather, round-the-clock operation.", "24/7, all-weather operation.")
add("index.html", "Pure-electric or range-extender configurations.", "Pure-electric or range-extender power.")
add("index.html",
    "From universal platforms to customized implements, we advance unmanned agriculture together with our partners.",
    "From platforms to customized implements, we advance unmanned farming with our partners.")

# ---------------- products.html ----------------
add("products.html", "Enquire", "Inquire", 2)
add("products.html",
    "A compact, agile platform for precision operations and medium payloads. Render for reference only; housing is a customizable option.",
    "A compact, agile platform for precision tasks and medium payloads. Image for reference only; housing is customizable.")
add("products.html",
    "A heavy-duty platform with range-extender power for large-field operations and heavy implements. Render for reference only; housing is customizable.",
    "A heavy-duty platform with range-extender power for large fields and heavy implements. Image for reference only; housing is customizable.")
add("products.html",
    "Note: As a modular platform, specifications may be adjusted per the final configuration.",
    "Note: As a modular platform, specifications may vary with the final configuration.", 2)
add("products.html",
    "Tell us your crop, field and operation needs — we deliver an integrated platform plus implement solution.",
    "Tell us your crop and field needs — we'll deliver an integrated platform and implement solution.")

# ---------------- about.html ----------------
add("about.html",
    "Bringing automotive electrification and intelligence into field autonomy and machine vision, enabling unmanned field operations.",
    "We apply automotive electrification and intelligence to field autonomy and machine vision, enabling unmanned farming.")
add("about.html",
    "Ningbo Wheelbots Robotics Co., Ltd. (WHEELBOTS) is a leader in intelligent, modular agricultural robots. We bring automotive electrification and intelligence into field autonomy and machine vision, enabling unmanned field operations through universal robot platforms.",
    "Wheelbots Co. Ltd. (WHEELBOTS) is a leader in intelligent, modular agricultural robots. We apply automotive electrification and intelligence to field autonomy and machine vision, enabling unmanned operations on universal robot platforms.")
add("about.html",
    "Customer-centric, with a flat organization and agile response, backed by a high-quality supply chain and top-tier operations — delivering quality at an affordable price.",
    "A customer-centric approach, flat organization and agile response, backed by a quality supply chain and top-tier operations — quality at an affordable price.")
add("about.html", "Informatized", "Digitalized")
add("about.html", "Shanghai Wheelbots Technology Co., Ltd. founded", "Wheelbots founded in Shanghai")
add("about.html", "Relocated to Ningbo; Ningbo Wheelbots Robotics Co., Ltd. established",
    "Relocated to Ningbo; Wheelbots Co. Ltd. established")

# ---------------- contact.html ----------------
add("contact.html", '"alternateName": "Ningbo Wheelbots Robotics Co., Ltd."',
    '"alternateName": "Wheelbots Co. Ltd."')
add("contact.html",
    "Whether it's product enquiry, customized implements or business partnership, we'd love to hear from you.",
    "For product inquiries, custom implements or partnerships, we'd love to hear from you.")
add("contact.html", "Ningbo Wheelbots Robotics Co., Ltd.", "Wheelbots Co. Ltd.")
add("contact.html", "For enquiries, please include your crop type and field conditions.",
    "For inquiries, please include your crop type and field conditions.")
add("contact.html", "Product Enquiry &amp; Customization", "Product Inquiry &amp; Customization")

# ---------------- cache-busting version bump ----------------
for f in ["index.html", "products.html", "about.html", "contact.html"]:
    add(f, "?v=20261020a", "?v=20261117a", 2)

# ---------------- apply with verification ----------------
failed = []
changed_files = set()
for f, old, new, expected in P:
    path = os.path.join(ROOT, f)
    s = io.open(path, encoding="utf-8").read()
    cnt = s.count(old)
    if cnt != expected:
        failed.append("FAIL %-18s expected=%d actual=%d :: %s" % (f, expected, cnt, old[:60]))
        continue
    s = s.replace(old, new)
    io.open(path, "w", encoding="utf-8").write(s)
    changed_files.add(f)

print("Applied %d / %d replacements." % (len(P) - len(failed), len(P)))
for x in failed:
    print(x)
print("Changed files:", ", ".join(sorted(changed_files)))
sys.exit(1 if failed else 0)
