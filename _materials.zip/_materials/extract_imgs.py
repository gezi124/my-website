from pptx import Presentation
import os

files = [
    r"C:\Users\yanxi\Desktop\通用型农业机器人平台\美化版\WB-51通用型农业机器人平台产品信息.pptx",
    r"C:\Users\yanxi\Desktop\通用型农业机器人平台\美化版\WB-300通用型农业机器人平台产品信息.pptx",
]
out = r"D:\workbuddy\2026-10-19-09-47-25\assets\img"
os.makedirs(out, exist_ok=True)

for f in files:
    prs = Presentation(f)
    base = os.path.splitext(os.path.basename(f))[0]
    count = 0
    for si, slide in enumerate(prs.slides):
        for shape in slide.shapes:
            if shape.shape_type == 13:  # PICTURE
                img = shape.image
                ext = img.ext
                name = f"{base}_img{count}.{ext}"
                with open(os.path.join(out, name), "wb") as fp:
                    fp.write(img.blob)
                print("saved", name, len(img.blob), "bytes")
                count += 1
    if count == 0:
        print(base, "-> no picture shapes found")
print("DONE")
